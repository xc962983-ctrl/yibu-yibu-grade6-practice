"use client";

import { useMemo, useState } from "react";

type Topic = "fractions" | "ratio" | "circle";

type Question = {
  id: string;
  topic: Topic;
  title: string;
  prompt: string;
  options: string[];
  answer: string;
  hint: string;
  steps: string[];
  takeaway: string;
};

const topics: Array<{ id: Topic; label: string; detail: string; icon: string }> = [
  { id: "fractions", label: "分数", detail: "通分、约分和计算", icon: "⅔" },
  { id: "ratio", label: "比和比例", detail: "把数量关系说清楚", icon: "↔" },
  { id: "circle", label: "圆与百分数", detail: "公式和生活题", icon: "◒" },
];

const textbookSubjects = [
  { name: "语文", detail: "统编版教材", symbol: "文", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E8%AF%AD%E6%96%87/%E7%BB%9F%E7%BC%96%E7%89%88" },
  { name: "数学", detail: "人教版教材", symbol: "数", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E6%95%B0%E5%AD%A6" },
  { name: "英语", detail: "小学英语教材", symbol: "英", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E8%8B%B1%E8%AF%AD" },
];

const questions: Question[] = [
  {
    id: "fraction-1",
    topic: "fractions",
    title: "分数加法",
    prompt: "小明上午喝了 1/3 杯牛奶，下午喝了 1/6 杯。一共喝了多少杯？",
    options: ["1/9 杯", "1/2 杯", "2/9 杯", "2/6 杯"],
    answer: "1/2 杯",
    hint: "分母不同，不能直接把分子相加。先把它们变成相同的分母。",
    steps: [
      "1/3 和 1/6 的分母不同，先通分。最小公倍数是 6。",
      "1/3 = 2/6，所以原题变成 2/6 + 1/6。",
      "分母不变，只把分子相加：2/6 + 1/6 = 3/6。",
      "3/6 约分为 1/2，所以一共喝了 1/2 杯。",
    ],
    takeaway: "分数相加时，先通分，再相加，最后检查能不能约分。",
  },
  {
    id: "fraction-2",
    topic: "fractions",
    title: "分数乘法",
    prompt: "一根绳子长 3/4 米，用去它的 2/3。用去了多少米？",
    options: ["1/2 米", "5/7 米", "2/3 米", "3/8 米"],
    answer: "1/2 米",
    hint: "求一个数的几分之几，用乘法。",
    steps: [
      "“用去它的 2/3”表示求 3/4 的 2/3，列式是 3/4 × 2/3。",
      "分子相乘、分母相乘：3 × 2 / (4 × 3) = 6/12。",
      "6/12 约分，分子分母同时除以 6，得到 1/2。",
      "所以用去了 1/2 米。",
    ],
    takeaway: "求一个数的几分之几，通常用这个数乘几分之几。",
  },
  {
    id: "ratio-1",
    topic: "ratio",
    title: "比的应用",
    prompt: "男生和女生人数的比是 3:2，全班共有 25 人。女生有多少人？",
    options: ["10 人", "12 人", "15 人", "20 人"],
    answer: "10 人",
    hint: "先看一共有几份，再求每一份是多少。",
    steps: [
      "3:2 表示男生占 3 份，女生占 2 份，一共是 3 + 2 = 5 份。",
      "每一份人数是 25 ÷ 5 = 5 人。",
      "女生占 2 份，所以女生有 5 × 2 = 10 人。",
    ],
    takeaway: "按比分配时：总数 ÷ 总份数 = 每份数量。",
  },
  {
    id: "ratio-2",
    topic: "ratio",
    title: "比例判断",
    prompt: "4:6 和下面哪个比能组成比例？",
    options: ["2:3", "3:2", "4:9", "6:4"],
    answer: "2:3",
    hint: "把 4:6 的前项和后项同时除以 2。",
    steps: [
      "4 和 6 的最大公因数是 2。",
      "4:6 的前项、后项同时除以 2，得到 2:3。",
      "所以 4:6 = 2:3，这两个比能组成比例。",
    ],
    takeaway: "比的前项和后项同时乘或除以同一个数，比值不变。",
  },
  {
    id: "circle-1",
    topic: "circle",
    title: "圆的周长",
    prompt: "一个圆的半径是 5 厘米，取 π = 3.14，它的周长是多少？",
    options: ["15.7 厘米", "31.4 厘米", "78.5 厘米", "10 厘米"],
    answer: "31.4 厘米",
    hint: "已知半径，圆的周长公式是 C = 2πr。",
    steps: [
      "题目给出半径 r = 5 厘米。",
      "套用公式：C = 2πr = 2 × 3.14 × 5。",
      "先算 2 × 5 = 10，再算 3.14 × 10 = 31.4。",
      "所以圆的周长是 31.4 厘米。",
    ],
    takeaway: "知道半径求周长：C = 2πr；知道直径求周长：C = πd。",
  },
  {
    id: "circle-2",
    topic: "circle",
    title: "百分数",
    prompt: "一本书原价 40 元，打八折后多少钱？",
    options: ["8 元", "20 元", "32 元", "36 元"],
    answer: "32 元",
    hint: "八折就是原价的 80%。",
    steps: [
      "八折 = 80% = 0.8。",
      "打折后的价格 = 原价 × 折数。",
      "40 × 0.8 = 32（元）。",
      "所以这本书打八折后是 32 元。",
    ],
    takeaway: "打几折就是原价的百分之几十，先把折数换成百分数或小数。",
  },
];

function getQuestions(topic: Topic) {
  return questions.filter((question) => question.topic === topic);
}

export default function Home() {
  const [topic, setTopic] = useState<Topic>("fractions");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const topicQuestions = useMemo(() => getQuestions(topic), [topic]);
  const question = topicQuestions[questionIndex % topicQuestions.length];
  const answeredCorrectly = selected === question.answer;

  function chooseTopic(nextTopic: Topic) {
    setTopic(nextTopic);
    setQuestionIndex(0);
    setSelected(null);
    setShowExplanation(false);
  }

  function chooseAnswer(option: string) {
    setSelected(option);
    setShowExplanation(true);
  }

  function nextQuestion() {
    setQuestionIndex((current) => (current + 1) % topicQuestions.length);
    setSelected(null);
    setShowExplanation(false);
  }

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="回到首页">
          <span className="brand-mark">小</span>
          <span>
            <strong>一步一步</strong>
            <small>六年级数学练习</small>
          </span>
        </a>
        <div className="topbar-actions">
          <span className="safe-pill"><span className="safe-dot" />无需注册</span>
          <button className="text-button" onClick={() => setShowGuide((open) => !open)}>
            给家长的说明
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">今天练 10 分钟</p>
          <h1>先自己想，<em>再看懂。</em></h1>
          <p className="hero-lede">
            一道题一道题练习。答错了也没关系，小老师会把每一步写清楚，直到真正明白。
          </p>
          <div className="hero-notes">
            <span>✓ 大字清楚</span><span>✓ 不用安装</span><span>✓ 错题有讲解</span>
          </div>
        </div>
        <div className="hero-card" aria-label="使用提示">
          <div className="hero-card-top"><span className="mini-label">给家长</span><span className="sun">☀</span></div>
          <h2>打开链接就能练</h2>
          <p>孩子先选答案，再按“看讲解”。每天做 3～5 题，比一次做很多题更有效。</p>
          <div className="progress-bubbles"><span /><span /><span /><span /><span /></div>
          <small>每完成一道，就点亮一颗小星星</small>
        </div>
      </section>

      <section className="content-grid">
        <div className="practice-column">
          <div className="section-heading">
            <div><p className="eyebrow">选择今天的主题</p><h2>从熟悉的地方开始</h2></div>
            <span className="question-count">每组 2 题</span>
          </div>

          <div className="topic-list" role="tablist" aria-label="练习主题">
            {topics.map((item) => (
              <button className={`topic-card ${topic === item.id ? "is-active" : ""}`} key={item.id} onClick={() => chooseTopic(item.id)} role="tab" aria-selected={topic === item.id}>
                <span className="topic-icon">{item.icon}</span>
                <span className="topic-text"><strong>{item.label}</strong><small>{item.detail}</small></span>
                <span className="topic-arrow">→</span>
              </button>
            ))}
          </div>

          <div className="practice-card">
            <div className="practice-header"><span className="question-tag">{question.title}</span><span className="question-number">第 {questionIndex + 1} / {topicQuestions.length} 题</span></div>
            <div className="question-progress"><span style={{ width: `${((questionIndex + 1) / topicQuestions.length) * 100}%` }} /></div>
            <h3>{question.prompt}</h3>
            <p className="try-first">先在心里算一算，再选择答案。</p>
            <div className="answer-grid">
              {question.options.map((option, index) => {
                const isSelected = selected === option;
                const isCorrect = option === question.answer;
                return (
                  <button className={`answer-button ${isSelected ? "is-selected" : ""} ${showExplanation && isCorrect ? "is-correct" : ""}`} key={option} onClick={() => chooseAnswer(option)}>
                    <span className="answer-letter">{String.fromCharCode(65 + index)}</span><span>{option}</span>
                    {showExplanation && isCorrect ? <span className="answer-check">✓</span> : null}
                  </button>
                );
              })}
            </div>

            <div className={`feedback ${selected ? (answeredCorrectly ? "feedback-good" : "feedback-warm") : "feedback-neutral"}`}>
              <div className="feedback-icon">{selected ? (answeredCorrectly ? "✓" : "i") : "?"}</div>
              <div><strong>{selected ? (answeredCorrectly ? "答对了，做得很好！" : "先别急，我们一起拆开来看。") : "遇到困难时，可以先看提示。"}</strong><p>{selected ? (answeredCorrectly ? "你已经掌握了这一步，下面看看完整方法，加深印象。" : question.hint) : question.hint}</p></div>
            </div>

            {showExplanation ? (
              <div className="explanation-panel">
                <div className="explanation-heading"><span className="spark">✦</span><div><p className="eyebrow">小老师分步讲解</p><h4>为什么答案是 {question.answer}？</h4></div></div>
                <ol className="steps-list">{question.steps.map((step) => <li key={step}><span>✓</span><p>{step}</p></li>)}</ol>
                <div className="takeaway"><strong>记住这一点</strong><span>{question.takeaway}</span></div>
                <button className="next-button" onClick={nextQuestion}>继续下一题 <span>→</span></button>
              </div>
            ) : null}
          </div>
        </div>

        <aside className="side-column">
          <div className="side-card side-card-green"><span className="side-card-label">今天的节奏</span><div className="streak-number">0 <small>题</small></div><p>慢一点没有关系，<br />把每一步弄明白就好。</p><div className="streak-track"><span /><span /><span /><span /><span /></div><small className="side-footnote">做 3 题就完成今天的小目标</small></div>
          <div className="side-card side-card-paper"><span className="side-card-label">遇到不会的题</span><h3>先读题，<br />再找关系。</h3><p>把题目中的“总共、每份、几倍、百分之几”圈出来，通常就能找到第一步。</p><span className="paper-mark">⌁</span></div>
        </aside>
      </section>

      <section className="textbook-section" aria-label="六年级教材中心">
        <div className="section-heading textbook-heading">
          <div><p className="eyebrow">六年级全科</p><h2>教材中心</h2></div>
          <a className="official-link" href="https://basic.smartedu.cn/tchMaterial" target="_blank" rel="noreferrer">打开国家平台 ↗</a>
        </div>
        <p className="textbook-note">按科目进入教材目录，再选择六年级上册或下册。教材文件不在本网页重复公开托管，家长直接从正规入口打开即可。</p>
        <div className="textbook-grid">
          {textbookSubjects.map((subject) => (
            <a className="textbook-card" href={subject.href} key={subject.name} target="_blank" rel="noreferrer">
              <span className="textbook-symbol">{subject.symbol}</span>
              <span><strong>{subject.name}</strong><small>{subject.detail}</small></span>
              <span className="textbook-arrow">↗</span>
            </a>
          ))}
        </div>
      </section>

      {showGuide ? <section className="parent-guide" aria-label="给家长的说明"><div><span className="guide-icon">☕</span><div><p className="eyebrow">给家长的说明</p><h2>这是练习工具，不是考试。</h2></div></div><p>建议让孩子先独立思考 1～2 分钟，再查看讲解。每次练 3～5 题即可。网页不要求注册，也不会保存孩子的个人信息。</p></section> : null}
      <footer className="footer"><span>一步一步 · 让每一道题都变得清楚一点</span><span>适合在 Mac 浏览器中使用</span></footer>
    </main>
  );
}
