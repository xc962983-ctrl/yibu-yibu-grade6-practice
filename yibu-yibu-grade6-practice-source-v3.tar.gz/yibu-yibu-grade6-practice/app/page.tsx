"use client";

import { useMemo, useState } from "react";

type Topic = "fractions" | "ratio" | "circle";

type Question = {
  id: string;
  topic: Topic;
  title: string;
  prompt: string;
  options: string[];
  answer: string;
  hint: string;
  steps: string[];
  takeaway: string;
};

const topics: Array<{ id: Topic; label: string; detail: string; icon: string }> = [
  { id: "fractions", label: "分数", detail: "通分、约分和计算 · 6 题", icon: "⅔" },
  { id: "ratio", label: "比和比例", detail: "按比分配和比例 · 6 题", icon: "↔" },
  { id: "circle", label: "圆与百分数", detail: "公式、折扣和生活题 · 6 题", icon: "◒" },
];

const textbookSubjects = [
  { name: "语文", detail: "统编版教材", symbol: "文", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E8%AF%AD%E6%96%87/%E7%BB%9F%E7%BC%96%E7%89%88" },
  { name: "数学", detail: "人教版教材", symbol: "数", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E6%95%B0%E5%AD%A6" },
  { name: "英语", detail: "小学英语教材", symbol: "英", href: "https://github.com/TapXWorld/ChinaTextbook/tree/master/%E5%B0%8F%E5%AD%A6/%E8%8B%B1%E8%AF%AD" },
];

const questions: Question[] = [
  {
    id: "fraction-1",
    topic: "fractions",
    title: "分数加法",
    prompt: "小明上午喝了 1/3 杯牛奶，下午喝了 1/6 杯。一共喝了多少杯？",
    options: ["1/9 杯", "1/2 杯", "2/9 杯", "2/6 杯"],
    answer: "1/2 杯",
    hint: "分母不同，不能直接把分子相加。先把它们变成相同的分母。",
    steps: [
      "1/3 和 1/6 的分母不同，先通分。最小公倍数是 6。",
      "1/3 = 2/6，所以原题变成 2/6 + 1/6。",
      "分母不变，只把分子相加：2/6 + 1/6 = 3/6。",
      "3/6 约分为 1/2，所以一共喝了 1/2 杯。",
    ],
    takeaway: "分数相加时，先通分，再相加，最后检查能不能约分。",
  },
  {
    id: "fraction-2",
    topic: "fractions",
    title: "分数乘法",
    prompt: "一根绳子长 3/4 米，用去它的 2/3。用去了多少米？",
    options: ["1/2 米", "5/7 米", "2/3 米", "3/8 米"],
    answer: "1/2 米",
    hint: "求一个数的几分之几，用乘法。",
    steps: [
      "“用去它的 2/3”表示求 3/4 的 2/3，列式是 3/4 × 2/3。",
      "分子相乘、分母相乘：3 × 2 / (4 × 3) = 6/12。",
      "6/12 约分，分子分母同时除以 6，得到 1/2。",
      "所以用去了 1/2 米。",
    ],
    takeaway: "求一个数的几分之几，通常用这个数乘几分之几。",
  },
  {
    id: "ratio-1",
    topic: "ratio",
    title: "比的应用",
    prompt: "男生和女生人数的比是 3:2，全班共有 25 人。女生有多少人？",
    options: ["10 人", "12 人", "15 人", "20 人"],
    answer: "10 人",
    hint: "先看一共有几份，再求每一份是多少。",
    steps: [
      "3:2 表示男生占 3 份，女生占 2 份，一共是 3 + 2 = 5 份。",
      "每一份人数是 25 ÷ 5 = 5 人。",
      "女生占 2 份，所以女生有 5 × 2 = 10 人。",
    ],
    takeaway: "按比分配时：总数 ÷ 总份数 = 每份数量。",
  },
  {
    id: "ratio-2",
    topic: "ratio",
    title: "比例判断",
    prompt: "4:6 和下面哪个比能组成比例？",
    options: ["2:3", "3:2", "4:9", "6:4"],
    answer: "2:3",
    hint: "把 4:6 的前项和后项同时除以 2。",
    steps: [
      "4 和 6 的最大公因数是 2。",
      "4:6 的前项、后项同时除以 2，得到 2:3。",
      "所以 4:6 = 2:3，这两个比能组成比例。",
    ],
    takeaway: "比的前项和后项同时乘或除以同一个数，比值不变。",
  },
  {
    id: "circle-1",
    topic: "circle",
    title: "圆的周长",
    prompt: "一个圆的半径是 5 厘米，取 π = 3.14，它的周长是多少？",
    options: ["15.7 厘米", "31.4 厘米", "78.5 厘米", "10 厘米"],
    answer: "31.4 厘米",
    hint: "已知半径，圆的周长公式是 C = 2πr。",
    steps: [
      "题目给出半径 r = 5 厘米。",
      "套用公式：C = 2πr = 2 × 3.14 × 5。",
      "先算 2 × 5 = 10，再算 3.14 × 10 = 31.4。",
      "所以圆的周长是 31.4 厘米。",
    ],
    takeaway: "知道半径求周长：C = 2πr；知道直径求周长：C = πd。",
  },
  {
    id: "circle-2",
    topic: "circle",
    title: "百分数",
    prompt: "一本书原价 40 元，打八折后多少钱？",
    options: ["8 元", "20 元", "32 元", "36 元"],
    answer: "32 元",
    hint: "八折就是原价的 80%。",
    steps: [
      "八折 = 80% = 0.8。",
      "打折后的价格 = 原价 × 折数。",
      "40 × 0.8 = 32（元）。",
      "所以这本书打八折后是 32 元。",
    ],
    takeaway: "打几折就是原价的百分之几十，先把折数换成百分数或小数。",
  },
  {
    id: "fraction-3",
    topic: "fractions",
    title: "分数减法",
    prompt: "一瓶果汁有 5/6 升，喝掉 1/4 升，还剩多少升？",
    options: ["7/12 升", "4/10 升", "2/3 升", "1/2 升"],
    answer: "7/12 升",
    hint: "先找到 6 和 4 的最小公倍数，再做减法。",
    steps: [
      "6 和 4 的最小公倍数是 12，先把两个分数通分。",
      "5/6 = 10/12，1/4 = 3/12。",
      "10/12 - 3/12 = 7/12。",
      "7/12 不能再约分，所以还剩 7/12 升。",
    ],
    takeaway: "异分母分数相减，也要先通分，再把分子相减。",
  },
  {
    id: "fraction-4",
    topic: "fractions",
    title: "分数除法",
    prompt: "2/5 ÷ 4/7 等于多少？",
    options: ["7/10", "8/35", "5/14", "2/7"],
    answer: "7/10",
    hint: "除以一个分数，等于乘这个分数的倒数。",
    steps: [
      "把除法改成乘法：2/5 ÷ 4/7 = 2/5 × 7/4。",
      "分子相乘、分母相乘，得到 14/20。",
      "14/20 的分子和分母同时除以 2，得到 7/10。",
    ],
    takeaway: "分数除法：除以一个分数，就乘它的倒数。",
  },
  {
    id: "fraction-5",
    topic: "fractions",
    title: "分数与小数",
    prompt: "0.75 化成最简分数是多少？",
    options: ["3/4", "75/10", "7/5", "1/3"],
    answer: "3/4",
    hint: "先把小数写成分母是 100 的分数，再约分。",
    steps: [
      "0.75 表示 75 个百分之一，可以写成 75/100。",
      "75 和 100 的最大公因数是 25。",
      "分子分母同时除以 25：75/100 = 3/4。",
    ],
    takeaway: "小数化分数后，最后要检查分数是否已经是最简分数。",
  },
  {
    id: "fraction-6",
    topic: "fractions",
    title: "约分",
    prompt: "15/24 约分后是多少？",
    options: ["5/8", "3/4", "8/15", "6/10"],
    answer: "5/8",
    hint: "找出 15 和 24 的最大公因数。",
    steps: [
      "15 和 24 的最大公因数是 3。",
      "分子分母同时除以 3：15 ÷ 3 = 5，24 ÷ 3 = 8。",
      "5 和 8 没有公因数 1 以外的因数，所以 5/8 是最简分数。",
    ],
    takeaway: "约分就是分子和分母同时除以它们的公因数。",
  },
  {
    id: "ratio-3",
    topic: "ratio",
    title: "比例中的未知数",
    prompt: "2:3 = 8:x，x 应该是多少？",
    options: ["12", "10", "6", "16"],
    answer: "12",
    hint: "2 变成 8 乘了 4，后项也要乘 4。",
    steps: [
      "左边的前项 2 变成 8，扩大了 4 倍。",
      "比例的前项扩大几倍，后项也要扩大几倍。",
      "x = 3 × 4 = 12。",
    ],
    takeaway: "在比例中，比的前项和后项要同时扩大或缩小相同的倍数。",
  },
  {
    id: "ratio-4",
    topic: "ratio",
    title: "按比分配",
    prompt: "甲、乙两数的比是 4:5，甲数是 28，乙数是多少？",
    options: ["35", "32", "36", "40"],
    answer: "35",
    hint: "先求出 1 份是多少，再求 5 份。",
    steps: [
      "甲的 4 份是 28，所以 1 份是 28 ÷ 4 = 7。",
      "乙有 5 份，所以乙数是 7 × 5 = 35。",
    ],
    takeaway: "已知一方数量和比份数时，可以先求每一份，再求另一方。",
  },
  {
    id: "ratio-5",
    topic: "ratio",
    title: "配制饮料",
    prompt: "红色果汁和清水的比是 2:5，一共配 35 毫升。清水有多少毫升？",
    options: ["25 毫升", "10 毫升", "14 毫升", "30 毫升"],
    answer: "25 毫升",
    hint: "清水占 5 份，总共是 7 份。",
    steps: [
      "总份数是 2 + 5 = 7 份。",
      "每份是 35 ÷ 7 = 5 毫升。",
      "清水有 5 份：5 × 5 = 25 毫升。",
    ],
    takeaway: "先把比转成总份数，再用总量除以总份数。",
  },
  {
    id: "ratio-6",
    topic: "ratio",
    title: "比例尺",
    prompt: "地图比例尺是 1:50000，图上 4 厘米表示实际多少千米？",
    options: ["2 千米", "20 千米", "200 米", "0.2 千米"],
    answer: "2 千米",
    hint: "先按比例算出实际厘米数，再把厘米换成千米。",
    steps: [
      "实际长度 = 图上长度 × 50000 = 4 × 50000 = 200000 厘米。",
      "100000 厘米等于 1 千米，200000 厘米就是 2 千米。",
    ],
    takeaway: "比例尺题要注意单位换算，厘米换成千米要除以 100000。",
  },
  {
    id: "circle-3",
    topic: "circle",
    title: "圆的面积",
    prompt: "一个圆的半径是 3 厘米，取 π = 3.14，它的面积是多少？",
    options: ["28.26 平方厘米", "18.84 平方厘米", "9.42 平方厘米", "56.52 平方厘米"],
    answer: "28.26 平方厘米",
    hint: "圆的面积公式是 S = πr²。",
    steps: [
      "半径 r = 3 厘米，先算半径的平方：3 × 3 = 9。",
      "套用公式：S = 3.14 × 9 = 28.26 平方厘米。",
    ],
    takeaway: "求圆的面积用 S = πr²，结果的单位是平方单位。",
  },
  {
    id: "circle-4",
    topic: "circle",
    title: "百分数增加",
    prompt: "一盒彩笔原价 50 元，涨价 20% 后是多少钱？",
    options: ["60 元", "70 元", "52 元", "40 元"],
    answer: "60 元",
    hint: "涨价后的价格是原价的 120%。",
    steps: [
      "涨价 20% 后，新的价格占原价的 100% + 20% = 120%。",
      "50 × 120% = 50 × 1.2 = 60 元。",
    ],
    takeaway: "涨价后的量 = 原来的量 ×（1 + 增长百分数）。",
  },
  {
    id: "circle-5",
    topic: "circle",
    title: "求百分之几",
    prompt: "一个班有 40 人，其中 35% 的同学参加了合唱队。参加合唱队的有多少人？",
    options: ["14 人", "12 人", "18 人", "35 人"],
    answer: "14 人",
    hint: "求一个数的百分之几，也用乘法。",
    steps: [
      "参加合唱队的人数 = 全班人数 × 参加比例。",
      "40 × 35% = 40 × 0.35 = 14 人。",
    ],
    takeaway: "求一个数的百分之几，用这个数乘百分数。",
  },
  {
    id: "circle-6",
    topic: "circle",
    title: "由直径求周长",
    prompt: "一个圆形钟面的直径是 10 厘米，取 π = 3.14，它的周长是多少？",
    options: ["31.4 厘米", "62.8 厘米", "15.7 厘米", "100 厘米"],
    answer: "31.4 厘米",
    hint: "已知直径时，圆的周长公式是 C = πd。",
    steps: [
      "题目给出直径 d = 10 厘米，不需要先求半径。",
      "C = πd = 3.14 × 10 = 31.4 厘米。",
    ],
    takeaway: "知道直径求周长，直接用 C = πd。",
  },
];

function getQuestions(topic: Topic) {
  return questions.filter((question) => question.topic === topic);
}

const sessionLengths = [5, 10, 15] as const;
type SessionLength = (typeof sessionLengths)[number];

export default function Home() {
  const [selectedTopics, setSelectedTopics] = useState<Topic[]>(topics.map((item) => item.id));
  const [sessionLength, setSessionLength] = useState<SessionLength>(10);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answerResults, setAnswerResults] = useState<Record<string, boolean>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const availableQuestions = useMemo(
    () => questions.filter((question) => selectedTopics.includes(question.topic)),
    [selectedTopics],
  );
  const sessionQuestions = useMemo(
    () => availableQuestions.slice(0, sessionLength),
    [availableQuestions, sessionLength],
  );
  const question = sessionQuestions[questionIndex] ?? sessionQuestions[0] ?? questions[0];
  const answeredCorrectly = selected === question.answer;
  const score = Object.values(answerResults).filter(Boolean).length;

  function resetPractice() {
    setQuestionIndex(0);
    setSelected(null);
    setAnswerResults({});
    setShowExplanation(false);
  }

  function toggleTopic(nextTopic: Topic) {
    setSelectedTopics((current) => {
      if (current.includes(nextTopic)) {
        if (current.length === 1) return current;
        return current.filter((item) => item !== nextTopic);
      }
      return [...current, nextTopic];
    });
    resetPractice();
  }

  function chooseSessionLength(nextLength: SessionLength) {
    setSessionLength(nextLength);
    resetPractice();
  }

  function chooseAnswer(option: string) {
    setSelected(option);
    setAnswerResults((current) => ({ ...current, [question.id]: option === question.answer }));
    setShowExplanation(true);
  }

  function nextQuestion() {
    if (questionIndex + 1 >= sessionQuestions.length) {
      resetPractice();
      return;
    }
    setQuestionIndex((current) => current + 1);
    setSelected(null);
    setShowExplanation(false);
  }

  return (
    <main className="site-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="回到首页">
          <span className="brand-mark">小</span>
          <span>
            <strong>一步一步</strong>
            <small>六年级数学练习</small>
          </span>
        </a>
        <div className="topbar-actions">
          <span className="safe-pill"><span className="safe-dot" />无需注册</span>
          <button className="text-button" onClick={() => setShowGuide((open) => !open)}>
            给家长的说明
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">今天练 10 分钟</p>
          <h1>先自己想，<em>再看懂。</em></h1>
          <p className="hero-lede">
            一道题一道题练习。答错了也没关系，小老师会把每一步写清楚，直到真正明白。
          </p>
          <div className="hero-notes">
            <span>✓ 大字清楚</span><span>✓ 不用安装</span><span>✓ 错题有讲解</span>
          </div>
        </div>
        <div className="hero-card" aria-label="使用提示">
          <div className="hero-card-top"><span className="mini-label">给家长</span><span className="sun">☀</span></div>
          <h2>打开链接就能练</h2>
          <p>孩子先选答案，再按“看讲解”。每天做 3～5 题，比一次做很多题更有效。</p>
          <div className="progress-bubbles"><span /><span /><span /><span /><span /></div>
          <small>每完成一道，就点亮一颗小星星</small>
        </div>
      </section>

      <section className="content-grid">
        <div className="practice-column">
          <div className="section-heading">
            <div><p className="eyebrow">选择今天的题库</p><h2>今天想练什么？</h2></div>
            <span className="question-count">已选 {selectedTopics.length} 个 · {availableQuestions.length} 题</span>
          </div>

          <div className="topic-list" role="group" aria-label="练习题库">
            {topics.map((item) => (
              <button className={`topic-card ${selectedTopics.includes(item.id) ? "is-active" : ""}`} key={item.id} onClick={() => toggleTopic(item.id)} aria-pressed={selectedTopics.includes(item.id)}>
                <span className="topic-icon">{item.icon}</span>
                <span className="topic-text"><strong>{item.label}</strong><small>{item.detail}</small></span>
                <span className="topic-arrow">{selectedTopics.includes(item.id) ? "✓" : "+"}</span>
              </button>
            ))}
          </div>

          <div className="bank-controls">
            <div><span className="control-label">本次练习题量</span><strong>安排 {Math.min(sessionLength, availableQuestions.length)} 题</strong></div>
            <div className="length-options" role="group" aria-label="选择练习题量">
              {sessionLengths.map((length) => (
                <button className={`length-button ${sessionLength === length ? "is-active" : ""}`} key={length} onClick={() => chooseSessionLength(length)} aria-pressed={sessionLength === length}>{length} 题</button>
              ))}
            </div>
            <span className="bank-summary">点击上面的题库卡片，可组合练习</span>
          </div>

          <div className="practice-card">
            <div className="practice-header"><span className="question-tag">{question.title}</span><span className="question-number">第 {questionIndex + 1} / {sessionQuestions.length} 题</span></div>
            <div className="question-progress"><span style={{ width: `${((questionIndex + 1) / sessionQuestions.length) * 100}%` }} /></div>
            <h3>{question.prompt}</h3>
            <p className="try-first">先在心里算一算，再选择答案。</p>
            <div className="answer-grid">
              {question.options.map((option, index) => {
                const isSelected = selected === option;
                const isCorrect = option === question.answer;
                return (
                  <button className={`answer-button ${isSelected ? "is-selected" : ""} ${showExplanation && isCorrect ? "is-correct" : ""}`} key={option} onClick={() => chooseAnswer(option)}>
                    <span className="answer-letter">{String.fromCharCode(65 + index)}</span><span>{option}</span>
                    {showExplanation && isCorrect ? <span className="answer-check">✓</span> : null}
                  </button>
                );
              })}
            </div>

            <div className={`feedback ${selected ? (answeredCorrectly ? "feedback-good" : "feedback-warm") : "feedback-neutral"}`}>
              <div className="feedback-icon">{selected ? (answeredCorrectly ? "✓" : "i") : "?"}</div>
              <div><strong>{selected ? (answeredCorrectly ? "答对了，做得很好！" : "先别急，我们一起拆开来看。") : "遇到困难时，可以先看提示。"}</strong><p>{selected ? (answeredCorrectly ? "你已经掌握了这一步，下面看看完整方法，加深印象。" : question.hint) : question.hint}</p></div>
            </div>

            {showExplanation ? (
              <div className="explanation-panel">
                <div className="explanation-heading"><span className="spark">✦</span><div><p className="eyebrow">小老师分步讲解</p><h4>为什么答案是 {question.answer}？</h4></div></div>
                <ol className="steps-list">{question.steps.map((step) => <li key={step}><span>✓</span><p>{step}</p></li>)}</ol>
                <div className="takeaway"><strong>记住这一点</strong><span>{question.takeaway}</span></div>
                <button className="next-button" onClick={nextQuestion}>{questionIndex + 1 >= sessionQuestions.length ? "完成本轮，重新开始" : "继续下一题"} <span>→</span></button>
              </div>
            ) : null}
          </div>
        </div>

        <aside className="side-column">
          <div className="side-card side-card-green"><span className="side-card-label">本轮完成情况</span><div className="streak-number">{score} <small>/ {sessionQuestions.length} 题</small></div><p>{score === 0 ? "慢一点没有关系，" : "已经开始积累分数，"}<br />把每一步弄明白就好。</p><div className="streak-track"><span className={score >= 1 ? "is-lit" : ""} /><span className={score >= 2 ? "is-lit" : ""} /><span className={score >= 3 ? "is-lit" : ""} /><span className={score >= 4 ? "is-lit" : ""} /><span className={score >= 5 ? "is-lit" : ""} /></div><small className="side-footnote">当前题库共 {availableQuestions.length} 题可练</small></div>
          <div className="side-card side-card-paper"><span className="side-card-label">遇到不会的题</span><h3>先读题，<br />再找关系。</h3><p>把题目中的“总共、每份、几倍、百分之几”圈出来，通常就能找到第一步。</p><span className="paper-mark">⌁</span></div>
        </aside>
      </section>

      <section className="textbook-section" aria-label="六年级教材中心">
        <div className="section-heading textbook-heading">
          <div><p className="eyebrow">六年级全科</p><h2>教材中心</h2></div>
          <a className="official-link" href="https://basic.smartedu.cn/tchMaterial" target="_blank" rel="noreferrer">打开国家平台 ↗</a>
        </div>
        <p className="textbook-note">按科目进入教材目录，再选择六年级上册或下册。教材文件不在本网页重复公开托管，家长直接从正规入口打开即可。</p>
        <div className="textbook-grid">
          {textbookSubjects.map((subject) => (
            <a className="textbook-card" href={subject.href} key={subject.name} target="_blank" rel="noreferrer">
              <span className="textbook-symbol">{subject.symbol}</span>
              <span><strong>{subject.name}</strong><small>{subject.detail}</small></span>
              <span className="textbook-arrow">↗</span>
            </a>
          ))}
        </div>
      </section>

      {showGuide ? <section className="parent-guide" aria-label="给家长的说明"><div><span className="guide-icon">☕</span><div><p className="eyebrow">给家长的说明</p><h2>这是练习工具，不是考试。</h2></div></div><p>建议让孩子先独立思考 1～2 分钟，再查看讲解。每次练 3～5 题即可。网页不要求注册，也不会保存孩子的个人信息。</p></section> : null}
      <footer className="footer"><span>一步一步 · 让每一道题都变得清楚一点</span><span>适合在 Mac 浏览器中使用</span></footer>
    </main>
  );
}
